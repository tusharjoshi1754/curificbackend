export { default as validator } from './validator';
export { default as deviceValidator } from './deviceValidation';
